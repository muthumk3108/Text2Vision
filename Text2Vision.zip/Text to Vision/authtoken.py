auth_token = "YOUR HUGGING FACE TOKEN HERE"
# How to get one: https://huggingface.co/docs/hub/security-tokens